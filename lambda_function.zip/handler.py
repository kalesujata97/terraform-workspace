import json
import boto3
import csv
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    try:
		print("Incoming Event: ", event)
		bucket_name=event["Records"][0]["s3"]["bucket"]["name"]
		file_name=event["Records"][0]["s3"]["object"]["key"]
		print("File " , file_name , " uploaded in " , bucket_name)
		
		s3 = boto3.resource('s3')
		dynamo_db = boto3.client('dynamodb')
		
		entry_list=[]
		file_content = s3.Object(bucket_name, file_name)
		entry_list = file_content.get()['Body'].read().decode().split('\n')
		
		read_csv=csv.reader(entry_list, delimiter=',',quotechar='"')
		print(read_csv)
		for row in read_csv:
			empid= row[0]
			name= row[1].replace(',','')
			salary= row[2].replace(',','')
			
			response=dynamo_db.put_item(
				TableName="Test",
				Item={
					'empid' : {'N':empid},
					'name': {'S':name},
					'salary': {'N':salary}
				}
			)
			print(response)
	except ClientError as e:
        print(e.response['Error']['Message'])